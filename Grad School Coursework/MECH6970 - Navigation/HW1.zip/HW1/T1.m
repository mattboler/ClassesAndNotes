clc; clear all; close all;

% 1 min = 1852 meters
