function p = traj_ht(t)
%
% parameter trajectory
p = [2.0/4.6771 + 3.5*abs(sin(0.1*t))];